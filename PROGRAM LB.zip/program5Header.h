#include<stdio.h>

// Function Prototype
unsigned int Addition(unsigned int , unsigned int );