#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
    int no;
    struct Node *next;
}NODE, *PNODE, **PPNODE;

int main()
{
    PNODE First = NULL;

    return 0;
}