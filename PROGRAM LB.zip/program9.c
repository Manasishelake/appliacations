// Display "Jay Ganesh" 5 times on screen

#include<stdio.h>

// Example of Sequance

int main()
{
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");
    printf("Jay Ganesh...\n");

    return 0;
}